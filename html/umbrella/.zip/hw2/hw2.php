<?php 
// author : Kade Cooper kaco0964@colorado.edu
// name : hw2.php
// purpose :  Web page showcasing option lists, check for digit, reading a file and functional code.
// date : 01/28/2017
// version : 3.0

#Title of Page
echo "
<html>
<head> <title> TLEN5841 HW2: Kade Cooper </title> </head>
<body>
";

#Display user fields and make input numbers only
	echo "<big>Welcome to the Option Webpage!</big><br><br> Please choose a file to display or list of week days to output below!<br><br>";
	echo "
	<form method=post action=hw2.php>
	File # Input:
	<select name=\"userOption\">
		<option value=\"-1\">Select...</option>
		<option value=\"0\">file1.txt</option>
		<option value=\"1\">file2.txt</option>
		<option value=\"2\">file3.txt</option>
		<option value=\"3\">file4.txt</option>
		<option value=\"4\">Days of the Week</option>
	</select>
	<input type=\"submit\" name=\"submit\" value=\"Submit\" /></p>
	</form>";

#Check to see the value submitted was a number and go to our switch statements. Else, display the days of the week
if (isset($_REQUEST['submit'])){
	#Display files or days of the week
	$userOption = $_REQUEST['userOption'];	
	if(is_numeric($userOption)){
		switch($userOption){
			case "0";
				$file = "file1.txt";
				checkFile($file);			
				displayContent($file);
			break;
			case "1";
				$file = "file2.txt";
				checkFile($file);
				displayContent($file);
			break;
			case "2";
				$file = "file3.txt";
				checkFile($file);
				displayContent($file);
			break;
			case "3";
				$file = "file4.txt";
				checkFile($file);
				displayContent($file);
			break;
			case "4";
				#Day Incrementer
				$dayOfWeekNum = 0;
				#Array of days for the week
				$weekDays=array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
				foreach ($weekDays as $weekDay) {
					echo "Day $dayOfWeekNum of the week is $weekDay <br> \n";
					$dayOfWeekNum++;
				} 
			break;
		}
	}
	#Error
	else{
		echo "[ERROR]: Your input was not a digit";
	}
}

function checkFile($file){
	if (file_exists("/var/www/html/hw2/$file")){
		echo "[SUCCESS]: Located and outputting $file contents<br><br>\n";
	}
	else {
		echo "[ERROR]: $file does not exist<br><br>\n";
	}

}

#General function to read contents of each file
function displayContent($file){
	$maxLineNumber = 0;
	$lines=file("/var/www/html/hw2/$file");
	foreach ($lines as $line){
		#Check to see if first character is a # and skip		
		if(substr($line, 0, 1) ==='#'){			
			#Remove lines from output by only displaying newline character			
			$line = substr($line, 0, -2);			
			#break;
		}
		#XSS Attacks Check! Not the most elegant solution but we know nothing should start with ">script> in these files 
		elseif(substr($line, 0,10) ==='"><script>'){
			echo "XSS Attack Detected! [FULL_SYSTEM_ALERT]: Tracing attack source...";
			break;		
		}		
		#Read only the first 100 lines		
		elseif($maxLineNumber > 100){
			break;
		}
		else{
			$line = trim($line);
			echo "$line<br>\n";
			$maxLineNumber++;
		}
	}
}
#Error output
#sudo tail -f /var/log/httpd/error_log

#EOL
echo "</body> </html>";
?>
