<?php 
#author : Kade Cooper kaco0964@colorado.edu
#name : hw1.php
#purpose :  Showcase a user interaction with random number generator. Check input type and handle error cases.
#date : 01/21/2017
#version : 3.0

#Title of Page
echo "
<html>
<head> <title> TLEN5841 HW1: Kade Cooper </title> </head>
<body>
";

#Display user fields and make input numbers only
	echo "<big>Welcome to the Random Number Webpage!</big><br><br> Please input random number between 0 and 20 below!<br><br>";
	echo "
	<form method=post action=hw1.php>
	Random Number Input:
	<input type=\"number\" id=\"input\" name=\"input\">
	<input type=\"submit\" value=\"Submit\" /></p>
	</form>";

#Compare computer number to user input and check that the user actually entered a number
#Trim accounts for 0 and '' string cases
if (isset($_POST['input']) and trim($_POST['input']) !== ''){

	#This sets our user input variable with the text given in the 'input' field
	$user_Input = $_POST['input'];

	#Generate Random Number
	$rand_Int=rand(0,20);

	#Clean page
	ob_end_clean();

	if ($user_Input == $rand_Int){
        	echo "Your number was: $user_Input<br><br>";
        	echo "The computer's generated number was: $rand_Int<br><br>";
		print "Congratulations! You guessed the right number!<br><br>";
		tryAgain();
	}
	elseif ($user_Input > 20 or $user_Input < 0){
        	echo "Your number was: $user_Input<br><br>";
        	echo "The computer's generated number was: $rand_Int<br><br>";
        	print "Your number is out of range. Please try again.";
		tryAgain();
	}
	elseif ($user_Input < $rand_Int){
        	echo "Your number was: $user_Input<br><br>";
        	echo "The computer's generated number was: $rand_Int<br><br>";
        	print "Your guess is less than the random number. Please try again.";
		tryAgain();
	}
	elseif ($user_Input > $rand_Int){
        	echo "Your number was: $user_Input<br><br>";
        	echo "The computer's generated number was: $rand_Int<br><br>";
        	print "Your guess is greater than the random number. Please try again.";
		tryAgain();
	}
	else{
     		print "You're not suppose to be here Flynn...";
	}
}
else{
	echo "<b>Please provide a number!</b>";
}

function tryAgain(){
	echo "<br><br>
	<form method=post action=hw1.php>
	<input type=\"submit\" value=\"Try Again?\" /></p>
	</form>";
}

#Error output
#sudo tail -f /var/log/httpd/error_log

#EOL
echo "</body> </html>";
?>
