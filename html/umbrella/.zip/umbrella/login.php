<?php
session_start();


//Setup look of the page
//Change index.php to user page
echo "
<center><big>Login Page</big><br><br><br><br>
	<form method=\"post\" action=\"index.php\">
    Username: <input type=text name=postUser value=\"\"></input><br>
    Password: <input type=password name=postPass value=\"\"></input><br>
    <br><input type=submit name=submit value=\"Submit\">
	</form>

		<FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Home\">

</center>
";

#Check if admin to send to 2Auth.php page
