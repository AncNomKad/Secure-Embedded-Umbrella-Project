<?php

	echo " <form method=\"post\" action=\"lockscreen.php\">
	       <center><input type=\"submit\" name=\"submit\" value=\"Lockdown!\" /></center></form>
		";

?>
