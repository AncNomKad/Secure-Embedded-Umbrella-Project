<?php
session_start();
include_once('/var/www/html/umbrella/header.php');

#Image Insertion
#echo "<img src=\"/var/www/html/umbrella/images/umbrella_landing.jpg\">";

#Clean and set all variables to be used in queries toward the database
  isset($_REQUEST['s']) ? $s = strip_tags($_REQUEST['s']) : $s= "";

#Redraw homepage
function homePage(){
        echo "<FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Home\">
        ";

}

echo"	
		<center>
		<big>Login or Select Division</big><br><br>
		<br>
		<FORM METHOD=\"LINK\" ACTION=\"login.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Login\">
		<br>
		<br>
		<FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Find Division\">
		</center>
";



#Switch Logic
$step = $_REQUEST['s'];
        if(is_numeric($step)) {
                switch($step)    {
                        case "0";
                        default:
                                ob_end_clean();
                                echo "<center> <table> <tr> <td> <b> <u> Bad PAGE </u></b> </td></tr> \n ";
                                
                                homePage();
                        break;
				}
		}



echo "</body> </html>";
?>
