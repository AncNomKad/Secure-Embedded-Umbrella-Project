<?php
include_once('/var/www/html/umbrella/header.php');

//Check network status
$connected = @fsockopen("localhost/umbrella/index.php", 80); 
                                        //website, port  (try 80 or 443)
    if ($connected){
        $is_conn = true; //action when connected
        fclose($connected);
	echo "<center>Network Status:
	<body>
	&#9745
	</body>
	</center>";
    }else{
        $is_conn = false; //action in connection failure
	echo "<center>Network Status:
	<body>
	&#9746
	</body>
	</center>";
    }
    return $is_conn;
?>
