<?php
session_start();

echo "
<center><big>2FA Page</big><br><br>
	<form method=\"post\" action=\"add.php?s=90\">
    <FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"LISTEN FOR TONE\"><br><br>
    Input Tone Sequence: <input type=password name=postPass value=\"\"></input><br>
    <br><input type=submit name=submit value=\"Submit\">
	</form>

		<FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Home\">

</center>
";
