<html>
	<head>
		<title> Umbrella Employee Database Directory </title>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	</head>
	<center>
	<br>
	<a href=index.php> Home <a> |
	<a href=lockscreen.php> Screen Saver <a> |
	<a href=status.php> Umbrella Network Status <a> |
	<a href=release.php> Release Web Lockdown <a> |
	<a href=lockdown.php> Activate Web Lockdown </a><br><br>
	<hr>
	<br>
	</center>


