<?php
#See code on Webpage
#Header ("Content-type: text/css; charset=utf-8");
	echo"
		<link href=\"css/bootstrap.css\" rel=\"stylesheet\">
		<link href=\"css/bootstrap-theme.min.css\" rel=\"stylesheet\">
		<link href=\"css/starter-template.css\" rel=\"stylesheet\">
		<center>
		<FORM METHOD=\"LINK\" ACTION=\"index.php\">
		<INPUT TYPE=\"submit\" VALUE=\"Escape Screensaver\">
		</center>
	";
?>
